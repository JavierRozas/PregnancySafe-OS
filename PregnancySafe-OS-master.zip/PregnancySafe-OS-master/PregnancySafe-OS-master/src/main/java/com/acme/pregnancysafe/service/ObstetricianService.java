package com.acme.pregnancysafe.service;

public interface ObstetricianService {
}
