package com.acme.pregnancysafe.service;

import org.springframework.stereotype.Service;

@Service
public class ObstetricianServiceImpl implements ObstetricianService{
}
