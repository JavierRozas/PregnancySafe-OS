package com.acme.pregnancysafe.model;

public class Obstetrician extends AuditModel {
}
