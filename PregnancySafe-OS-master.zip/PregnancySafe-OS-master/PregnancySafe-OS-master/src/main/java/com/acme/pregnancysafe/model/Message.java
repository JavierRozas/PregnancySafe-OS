package com.acme.pregnancysafe.model;

public class Message {
}
