package com.acme.pregnancysafe.resource;

public class MotherResource {
}
