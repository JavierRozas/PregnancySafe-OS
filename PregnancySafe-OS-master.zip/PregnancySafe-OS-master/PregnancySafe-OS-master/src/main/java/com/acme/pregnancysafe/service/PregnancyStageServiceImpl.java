package com.acme.pregnancysafe.service;

import org.springframework.stereotype.Service;

@Service
public class PregnancyStageServiceImpl implements PregnancyStageService{
}
