package com.acme.pregnancysafe.service;

import org.springframework.stereotype.Service;

@Service
public class ChatServiceImpl implements ChatService{
}
