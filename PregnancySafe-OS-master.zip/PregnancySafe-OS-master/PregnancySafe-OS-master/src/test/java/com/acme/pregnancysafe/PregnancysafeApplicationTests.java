package com.acme.pregnancysafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PregnancysafeApplicationTests {

    @Test
    void contextLoads() {
    }

}
